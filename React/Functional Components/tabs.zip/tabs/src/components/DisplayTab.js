const DisplayTab = props => {
    return (
        <p className="App-logo">{props.content}</p>
    );
};

export default DisplayTab;